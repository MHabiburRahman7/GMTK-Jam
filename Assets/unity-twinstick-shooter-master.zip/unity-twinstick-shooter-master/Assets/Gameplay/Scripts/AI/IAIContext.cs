﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestGame.AI
{
    /// <summary>
    /// Provides common type for all contexts.
    /// </summary>
    public interface IAIContext
    {
    }
}
