﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TestGame.AI;
using UnityEngine;

namespace TestGame.Bots.Scorers
{
    public class ProximityToPlayer : AIScorer
    {
        public override float Score(IAIContext context)
        {
            throw new NotImplementedException();
        }
    }
}
