# Twin Stick Shooter

This is an Unity 3D project with sample TwinStick Shooter game prototype.

## Video

[![YouTube](http://img.youtube.com/vi/ek1AhqwDWj4/0.jpg)](http://www.youtube.com/watch?v=ek1AhqwDWj4 "Twinstick Shooter")
